package me.leefeng.lfrecyclerview;

/**
 * Created by limxing on 16/7/23.
 *
 * https://github.com/limxing
 * Blog: http://www.leefeng.me
 */
public interface OnItemClickListener {
    void onClick(int position);

    void onLongClick(int po);
}
